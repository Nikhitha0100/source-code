import React from "react";
import { View, Text, Pressable, Image } from "react-native";

const styles = {
  box: {
    width: "48%",
    height: 80,
    background: "#D7E4FF",
    borderRadius: 4,
    flexDirection: "row",
    padding: 12
  },
  input: {
    background: "#D7E4FF",
    paddingHorizontal: 12,
    paddingVertical: 12,
    borderRadius: 12
  }
};

export const AddActivity = ({ navigate }) => {
  return (
    <View style={{ flex: 1, paddingHorizontal: 16 }}>
      <View style={{ flexDirection: "row", paddingVertical: 16 }}>
        <Pressable
          onPress={() => {
            navigate("landing");
          }}
          style={{ heihgt: 14, width: 16 }}
        >
          {/* <Image src={{}} /> */}
          <Text style={{ fontSize: 20 }}>{"<"}</Text>
        </Pressable>
        <View style={{ width: 16 }} />
        <Text style={{ fontSize: 20 }}>Add activity</Text>
      </View>
      <View style={{ height: 16 }} />
      <View style={styles.input}>
        <Text>1 Month Medication</Text>
      </View>
      <View style={{ height: 16 }} />
      <View>
        <Text style={{ fontSize: 16 }}>Set limits</Text>
        <View style={{ height: 16 }} />

        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <View style={{ flexDirection: "row", width: "60%" }}>
            <View
              style={{
                backgroundColor: "#96B9F3",
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 12
              }}
            >
              <Text style={{ fontSize: 20 }}>+</Text>
            </View>
            <View style={{ width: 8 }} />
            <View style={[styles.input, { width: "100%" }]}>
              <Text>Tablets</Text>
            </View>
          </View>
          <View
            style={{
              paddingHorizontal: 16,
              paddingVertical: 10,
              backgroundColor: "#FF7070",
              borderRadius: 22
            }}
          >
            <Text style={{ fontSize: 20 }}>X</Text>
          </View>
        </View>
        <View style={{ height: 12 }} />
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <View style={{ flexDirection: "row", width: "60%" }}>
            <View
              style={{
                backgroundColor: "#96B9F3",
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 12
              }}
            >
              <Text style={{ fontSize: 20 }}>+</Text>
            </View>
            <View style={{ width: 8 }} />
            <View style={[styles.input, { width: "100%" }]}>
              <Text>Tablets</Text>
            </View>
          </View>
          <View
            style={{
              paddingHorizontal: 16,
              paddingVertical: 10,
              backgroundColor: "#FF7070",
              borderRadius: 22
            }}
          >
            <Text style={{ fontSize: 20 }}>X</Text>
          </View>
        </View>

        <View style={{ height: 44 }} />

        <View style={{ paddingHorizontal: 40 }}>
          <Pressable
            style={{
              paddingHorizontal: 44,
              paddingVertical: 12,
              background: "#5089ff",
              borderRadius: 12,
              width: "100%",
              alignItems: "center"
            }}
          >
            <Text style={{ color: "#fff" }}>Add more</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};
