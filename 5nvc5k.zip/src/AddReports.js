import React from "react";
import { View, Text, Pressable, Image } from "react-native";

const styles = {
  box: {
    width: "48%",
    height: 80,
    background: "#D7E4FF",
    borderRadius: 4,
    flexDirection: "row",
    padding: 12
  }
};

export const AddReports = ({ navigate }) => {
  return (
    <View style={{ flex: 1, paddingHorizontal: 16 }}>
      <View style={{ flexDirection: "row", paddingVertical: 16 }}>
        <Pressable
          onPress={() => {
            navigate("landing");
          }}
          style={{ heihgt: 14, width: 16 }}
        >
          {/* <Image src={{}} /> */}
          <Text style={{ fontSize: 20 }}>{"<"}</Text>
        </Pressable>
        <View style={{ width: 16 }} />
        <Text style={{ fontSize: 20 }}>Add</Text>
      </View>
      <View style={{ height: 16 }} />
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <View style={styles.box}>
            <Text style={{ fontSize: 18, fontWeight: "500" }}>
              Upload reports
            </Text>
            <View style={{ width: "40%" }}>
              <Image source={{}} />
            </View>
          </View>
          <View style={styles.box}>
            <Text style={{ fontSize: 18, fontWeight: "500" }}>
              Review reports
            </Text>
            <View style={{ width: "40%" }}>
              <Image source={{}} />
            </View>
          </View>
        </View>
        <View style={{ height: 24 }} />
        <Text style={{ fontWeight: "500" }}>Recentky Added</Text>
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <Text style={{ fontSize: 16, fontWeight: "500" }}>Whoohoo</Text>
          <View style={{ height: 8 }} />
          <Text>Lorem impsum...</Text>
        </View>
      </View>
    </View>
  );
};
