import React, { useState } from "react";
import { CreateAccount } from "./CreateAccount";
import { Verification } from "./Verification";
import { Notifications } from "./Notifications";
import { Landing } from "./Landing";
import { Splash } from "./Splash";
import { Profile } from "./Profile";

function App() {
  const [screen, setScreen] = useState("splash");

  if (screen === "create") {
    return (
      <CreateAccount
        onCreate={() => {
          setScreen("verification");
        }}
      />
    );
  }

  if (screen === "verification") {
    return (
      <Verification
        onDone={() => {
          setScreen("notifications");
        }}
      />
    );
  }

  if (screen === "notifications") {
    return (
      <Notifications
        onDone={() => {
          setScreen("landing");
        }}
      />
    );
  }

  if (screen === "landing") {
    return <Landing />;
  }

  if (screen === "profile") {
    return (
      <Profile
        home={() => {
          setScreen("home");
        }}
      />
    );
  }

  return (
    <Splash
      onDone={() => {
        setScreen("create");
      }}
    />
  );
}

export default App;
