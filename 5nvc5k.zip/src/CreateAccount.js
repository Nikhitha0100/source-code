import React from "react";
import { View, Text, TextInput, Button, Pressable } from "react-native";

const styles = {
  input: {
    paddingHorizontal: 16,
    background: "#d7e4ff",
    borderRadius: 20,
    paddingVertical: 12
  }
};

export function CreateAccount({ onCreate }) {
  return (
    <View>
      <View style={{ padding: 32 }}>
        <View>
          <View style={{ height: 16 }} />
          <Text style={{ fontSize: 24 }}>Create Account</Text>
          <View style={{ height: 32 }} />

          <View>
            <TextInput style={styles.input} placeholder="Name" />
            <View style={{ height: 16 }} />
            <TextInput style={styles.input} placeholder="Mobile number" />
            <View style={{ height: 16 }} />
            <TextInput style={styles.input} placeholder="Email" />
            <View style={{ height: 16 }} />
            <TextInput style={styles.input} placeholder="Password" />
            <View style={{ height: 16 }} />
            <TextInput style={styles.input} placeholder="Confirm password" />
          </View>

          <View style={{ paddingHorizontal: 16, alignItems: "center" }}>
            <View style={{ height: 16 }} />
            <Text style={{ fontSize: 14, color: "#b1b2b4" }}>
              Lorem impsum...
            </Text>
            <View style={{ height: 24 }} />
            <Pressable
              style={{
                paddingHorizontal: 44,
                paddingVertical: 12,
                background: "#5089ff",
                borderRadius: 12
              }}
              onPress={onCreate}
            >
              <Text style={{ color: "#fff" }}>Sign up </Text>
            </Pressable>
            <View style={{ height: 16 }} />
            <Text style={{ color: "#b1b2b4" }}>Or</Text>
            <View style={{ height: 16 }} />
            <Text>Sign up with Google</Text>
            <View style={{ height: 32 }} />
            <Text style={{ color: "#b1b2b4", fontSize: 12 }}>
              Already have account
              <Text style={{ color: "#000" }}> Login</Text>
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

export default CreateAccount;
