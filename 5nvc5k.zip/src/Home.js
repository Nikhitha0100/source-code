import React from "react";
import { View, Text, Pressable, Image } from "react-native";

export const Home = ({ navigate }) => {
  return (
    <View style={{ flex: 1 }}>
      <View
        style={{
          background: "#d6e4fe",
          padding: 16,
          flexDirection: "row",
          justifyContent: "space-between"
        }}
      >
        <View>
          <Text>Hello!</Text>
          <Text style={{ fontSize: 20, fontWeight: "500" }}>Michel</Text>
        </View>
        <View>
          <View style={{ background: "#5088ff", padding: 8, borderRadius: 12 }}>
            <Image src={{}} alt="bell" />
            <View style={{ width: 4 }} />
            <Text style={{ color: "#fff" }}>2</Text>
          </View>
        </View>
      </View>
      <View style={{ flex: 1, justifyContent: "flex-end" }}>
        <View style={{ padding: 16 }}>
          <Text style={{ fontSize: 18 }}>Explore</Text>
          <View style={{ height: 16 }} />
          <View
            style={{ padding: 12, backgroundColor: "#7f42ff", borderRadius: 6 }}
          >
            <Text style={{ color: "#fff" }}>Track todays behevior</Text>
          </View>
          <View style={{ height: 12 }} />
          <Pressable
            onPress={() => {
              navigate("reports");
            }}
          >
            <View
              style={{
                padding: 12,
                backgroundColor: "#7f42ff",
                borderRadius: 6
              }}
            >
              <Text style={{ color: "#fff" }}>Reports</Text>
            </View>
          </Pressable>
        </View>
      </View>
      <View>
        <View
          style={{
            padding: 12,
            flexDirection: "row",
            justifyContent: "space-between",
            borderTopWidth: 1,
            borderTopColor: "#ccc",
            paddingHorizontal: 16
          }}
        >
          <View style={{ width: 24, height: 24 }}>
            {/* <Image source={{}} /> */}
            <Text>H</Text>
          </View>
          <Pressable
            onPress={() => {
              navigate("reports");
            }}
          >
            <View style={{ width: 24, height: 24 }}>
              {/* <Image source={{}} /> */}
              <Text>AR</Text>
            </View>
          </Pressable>
          <Pressable
            onPress={() => {
              navigate("addActivity");
            }}
          >
            <View style={{ width: 24, height: 24 }}>
              {/* <Image source={{}} /> */}
              <Text>AT</Text>
            </View>
          </Pressable>
          <Pressable
            onPress={() => {
              navigate("profile");
            }}
          >
            <View style={{ width: 24, height: 24 }}>
              {/* <Image source={{}} /> */}
              <Text>PF</Text>
            </View>
          </Pressable>
        </View>
      </View>
    </View>
  );
};
