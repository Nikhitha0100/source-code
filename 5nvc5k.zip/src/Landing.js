import React, { useState } from "react";
import {} from "react-native";

import { Home } from "./Home";
import { Profile } from "./Profile";
import { AddReports } from "./AddReports";
import { AddActivity } from "./AddActivity";

export const Landing = () => {
  const [screen, setScreen] = useState();

  if (screen === "profile") {
    return (
      <Profile
        navigate={(screen) => {
          setScreen(screen);
        }}
      />
    );
  }

  if (screen === "reports") {
    return (
      <AddReports
        navigate={(screen) => {
          setScreen(screen);
        }}
      />
    );
  }
  if (screen === "addActivity") {
    return (
      <AddActivity
        navigate={(screen) => {
          setScreen(screen);
        }}
      />
    );
  }

  return (
    <Home
      navigate={(screen) => {
        setScreen(screen);
      }}
    />
  );
};
