import React from "react";
import { View, Text, Pressable, Image } from "react-native";

export const Notification = ({ navigate }) => {
  return (
    <View style={{ flex: 1, paddingHorizontal: 16 }}>
      <View style={{ flexDirection: "row", paddingVertical: 16 }}>
        <Pressable
          onPress={() => {
            navigate("landing");
          }}
          style={{ heihgt: 14, width: 16 }}
        >
          {/* <Image src={{}} /> */}
          <Text style={{ fontSize: 20 }}>{"<"}</Text>
        </Pressable>
        <View style={{ width: 16 }} />
        <Text style={{ fontSize: 20 }}>Add activity</Text>
      </View>
      <View style={{ height: 16 }} />
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text style={{ fontSize: 22, color: "#ccc" }}>No messages</Text>
      </View>
    </View>
  );
};
