import React from "react";
import { View, Text, Pressable } from "react-native";

const styles = {
  input: {
    paddingHorizontal: 16,
    background: "#000",
    borderRadius: 20,
    paddingVertical: 12,
    width: "100%"
  }
};

export const Notifications = ({ onDone }) => {
  return (
    <View style={{ flex: 1 }}>
      <View
        style={{ justifyContent: "center", flex: 1, paddingHorizontal: 40 }}
      >
        <Text style={{ fontSize: 24 }}>Notifications</Text>
        <View style={{ height: 24 }} />
        <Text style={{ color: "#b1b2b4", fontSize: 12 }}>Lorem impsum....</Text>
        <View style={{ height: 32 }} />
        <View style={styles.input}>
          <Text style={{ color: "#fff" }}>Option</Text>
        </View>
        <View style={{ height: 38 }} />
        <Pressable
          style={{
            paddingHorizontal: 44,
            paddingVertical: 12,
            background: "#5089ff",
            borderRadius: 12,
            width: "100%",
            alignItems: "center"
          }}
          onPress={onDone}
        >
          <Text style={{ color: "#fff" }}>Done</Text>
        </Pressable>
      </View>
    </View>
  );
};
