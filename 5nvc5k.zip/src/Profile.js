import React from "react";
import { View, Text, Pressable, Image } from "react-native";

export const Profile = ({ navigate }) => {
  return (
    <View style={{ flex: 1, paddingHorizontal: 32 }}>
      <View style={{ flexDirection: "row", paddingVertical: 16 }}>
        <Pressable
          onPress={() => {
            navigate("landing");
          }}
          style={{ heihgt: 14, width: 16 }}
        >
          {/* <Image src={{}} /> */}
          <Text style={{ fontSize: 20 }}>{"<"}</Text>
        </Pressable>
        <View style={{ width: 16 }} />
        <Text style={{ fontSize: 20 }}>Accounts</Text>
      </View>

      <View
        style={{
          flexDirection: "row",
          paddingVertical: 16,
          alignItems: "center"
        }}
      >
        {/* <Image src={{}} style={{ height: 40, width: 40 }} /> */}
        <View
          style={{
            width: 50,
            height: 50,
            backgroundColor: "#D7E4FF",
            borderRadius: 22
          }}
        />
        <View style={{ width: 16 }} />
        <Text style={{ fontSize: 18 }}>Michel</Text>
      </View>

      <>
        <View style={{ flexDirection: "row", paddingVertical: 12 }}>
          {/* <Image src={{}} style={{ height: 20, width: 20 }} /> */}
          <View
            style={{
              width: 24,
              height: 24,
              backgroundColor: "#D7E4FF",
              borderRadius: 12
            }}
          />
          <View style={{ width: 16 }} />
          <Text style={{ fontSize: 18 }}>User name</Text>
        </View>
        <View style={{ flexDirection: "row", paddingVertical: 12 }}>
          {/* <Image src={{}} style={{ height: 20, width: 20 }} /> */}
          <View
            style={{
              width: 24,
              height: 24,
              backgroundColor: "#D7E4FF",
              borderRadius: 12
            }}
          />
          <View style={{ width: 16 }} />
          <Text style={{ fontSize: 18 }}>User name</Text>
        </View>
        <View style={{ flexDirection: "row", paddingVertical: 12 }}>
          {/* <Image src={{}} style={{ height: 20, width: 20 }} /> */}
          <View
            style={{
              width: 24,
              height: 24,
              backgroundColor: "#D7E4FF",
              borderRadius: 12
            }}
          />
          <View style={{ width: 16 }} />
          <Text style={{ fontSize: 18 }}>User name</Text>
        </View>
      </>
    </View>
  );
};
