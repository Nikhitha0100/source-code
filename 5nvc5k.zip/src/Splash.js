import React from "react";
import { View, Text, Pressable, Image } from "react-native";

const styles = {
  input: {
    paddingHorizontal: 16,
    background: "#000",
    borderRadius: 20,
    paddingVertical: 12,
    width: "100%"
  }
};

export const Splash = ({ onDone }) => {
  return (
    <View style={{ flex: 1 }}>
      <View
        style={{ justifyContent: "center", flex: 1, paddingHorizontal: 40 }}
      >
        <View style={{ alignItems: "center" }}>
          <View style={{ height: 340 }}>
            <Image src={{}} />
          </View>
          <View style={{ height: 20 }} />
          <Text>Welcome to</Text>
          <View style={{ height: 6 }} />
          <View style={{ flexDirection: "row" }}>
            <Image src={{}} style={{ width: 16, height: 16 }} />
            <Text style={{ fontSize: 24, color: "#3e80ea" }}>
              Healthy Together
            </Text>
          </View>
          <View style={{ height: 4 }} />
          <Text style={{ fontSize: 12 }}>lorem impsum...</Text>
          <View style={{ height: 24 }} />
          <Pressable
            style={{
              paddingHorizontal: 44,
              paddingVertical: 12,
              background: "#6febed",
              borderRadius: 12,
              width: "100%",
              alignItems: "center"
            }}
            onPress={onDone}
          >
            <Text style={{ color: "#fff" }}>Next</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
};
