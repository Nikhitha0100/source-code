import React from "react";
import { View, Text, TextInput, Pressable } from "react-native";
import { CreateAccount } from "./CreateAccount";

const styles = {
  input: {
    paddingHorizontal: 11,
    background: "#d7e4ff",
    borderRadius: 4,
    paddingVertical: 8,
    width: 30
  }
};

export const Verification = ({ onDone }) => {
  return (
    <View style={{ flex: 1 }}>
      <View
        style={{ justifyContent: "center", flex: 1, paddingHorizontal: 32 }}
      >
        <Text style={{ fontSize: 24 }}>Verification</Text>
        <Text style={{ fontSize: 12, color: "#b1b2b4" }}>
          Please enter your OTP
        </Text>
        <View style={{ height: 32 }} />
        <View style={{ flexDirection: "row" }}>
          <TextInput style={styles.input} />
          <View style={{ width: 16 }} />
          <TextInput style={styles.input} />
          <View style={{ width: 16 }} />
          <TextInput style={styles.input} />
          <View style={{ width: 16 }} />
          <TextInput style={styles.input} />
          <View style={{ width: 16 }} />
          <TextInput style={styles.input} />
          <View style={{ width: 16 }} />
          <TextInput style={styles.input} />
          <View style={{ width: 16 }} />
        </View>
        <View style={{ height: 8 }} />
        <View style={{ alignSelf: "flex-end" }}>
          <Text style={{ fontSize: 12, color: "#b1b2b4" }}>Reset password</Text>
        </View>
        <View style={{ height: 24 }} />
        <Pressable
          style={{
            paddingHorizontal: 44,
            paddingVertical: 12,
            background: "#5089ff",
            borderRadius: 12,
            alignSelf: "center"
          }}
          onPress={onDone}
        >
          <Text style={{ color: "#fff" }}>Done</Text>
        </Pressable>
      </View>
    </View>
  );
};
